package edu.atria.oops.firstpackage;

public class Executor {

	public static void main(String[] args) {
		Base bOne = new Base();
		System.out.println(bOne.varDefault);
		System.out.println(bOne.varPublic);
		//System.out.println(bOne.varPrivate.It is private so it is not visible
		//Private are not visible outside the class
		System.out.println(bOne.varProtected);

	}
;
}
