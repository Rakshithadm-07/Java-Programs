package edu.atria.oops.methodoverloadingdemo;

public class Overloadingdemo {

	public static void main(String[] args) {
		System.out.println(".................Method Overloading..................");
		System.out.println("Addition of two integer :" + MethodOverloading.add(10,20));
		System.out.println("Addition of two float :" + MethodOverloading.add(10.5f,20.5f));
		System.out.println("Addition of two integer and float :" + MethodOverloading.add(10,20.5f));
		System.out.println("Addition of two float and integer :" + MethodOverloading.add(10.5f,20));
		System.out.println("Addition of two String :" + MethodOverloading.add("Rakshitha"," B"));

	}

}
