package edu.atria.oops.multithreading;

class Hii extends Thread
{
	public void run()
	{
		for(int i=0;i<5;i++)
		{
			System.out.println("Hii");
			try
			{
				Thread.sleep(500);
			}
			catch(Exception e)
			{
		}
	}
}
}
class Hello extends Thread
{
	public void run()
	{
		for(int i=0;i<5;i++)
		{
			System.out.println("Hello");
			try
			{
				Thread.sleep(500);
			}
			catch(Exception e)
			{
		}
		}
	}
}

public class App {
		public static void main(String[] args) throws InterruptedException
		{
			Hii obj = new Hii();
			Hello obj1 = new Hello();
			
			Thread t1 = new Thread(obj);
			t1.start();

			try
			{
				Thread.sleep(300);
			}
			catch(Exception e)
			{
		}
			Thread t2 = new Thread(obj1);
			t2.start();
			
			t1.setPriority(Thread.MAX_PRIORITY);
			
			System.out.println(t1.getPriority());
			System.out.println(t2.getPriority());
			
			t1.join();
			t2.join();
			
			System.out.println("Good Afternoon");
			
		}
	}


