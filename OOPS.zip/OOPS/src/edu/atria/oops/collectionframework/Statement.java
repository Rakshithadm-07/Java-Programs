package edu.atria.oops.collectionframework;

public interface Statement {
	public abstract String greet();
	//public int calculate();
	//functional interface has only one abstract method
	

}
