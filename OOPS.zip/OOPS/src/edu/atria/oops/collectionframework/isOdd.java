package edu.atria.oops.collectionframework;

public interface isOdd {
	public boolean checkOdd(int a);

}
