package edu.atria.oops.abstractiondemo;

public abstract class Shape {
	//static float area;
	float area;
	//abstract method;
	public abstract float calculateArea();
	
	
	//Non abstract method
	/*public static void display() {
		System.out.println("Area of the shape: "+ area);
		
//An abstract class can have both abstract and non abstract method;
//If there is atleast one abstract method with in a class then the class should be an abstract class;
//abstract can have a static and final method;	
//The succlass which extends the abstract base class should implement the abstract method;	
	}*/
	
	public void display() {
		System.out.println("Area of the shape:"+area);
	}
	
	

}
