package edu.atria.oops.abstractiondemo;

public class AbstractClassMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Shape s = new Shape();it is not possible because shape is abstract class;
		//Cannot intantiate abstract class shape;
		
		
		Shape sOne = new Square(2.5f);
		sOne.calculateArea();
		sOne.display();
		
		Shape sTwo = new Rectangle(7f,5.5f);
		sTwo.calculateArea();
		sTwo.display();
		
		

	}

}
