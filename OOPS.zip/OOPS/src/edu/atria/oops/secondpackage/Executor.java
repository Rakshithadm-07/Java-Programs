package edu.atria.oops.secondpackage;

import edu.atria.oops.firstpackage.Base;

public class Executor extends Base{

	public static void main(String[] args) {
		Base bOne = new Base();
		//System.out.println(bOne.varPrivate);
		//Default is only in same package but not visible in other packge or outside the package
		//System.out.println(bOne.varDefault);
		//Protected is only visible within the package not visible in outside or other package
		//But we can get protected by adding getter method in base of the first package;
		//System.out.println(bOne.getVarProtected());
		//Protected memenbers are accessible outside the package by extending the package
		Executor ex = new Executor();
		System.out.println(ex.varProtected);
		System.out.println(bOne.varPublic);
		//public is visible in all package because it is public
		//Public is accessible everywhere;

	}

}
