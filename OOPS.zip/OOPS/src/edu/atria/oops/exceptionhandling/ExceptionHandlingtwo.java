package edu.atria.oops.exceptionhandling;

public class ExceptionHandlingtwo {
	
	public void Demo()
	{
		int a = 5/0;
		System.out.println(a);
	}
	public void Slave()
	{
		try
		{
			Demo();
			
		}
		catch(Exception e)
		{
			System.out.println("Exception---->"+e);
		}
	}
	public static void main(String[] args)
	{
		ExceptionHandlingtwo obj = new ExceptionHandlingtwo();
		obj.Slave();
		try
		{
			int a =5/0;
			System.out.println(a);
			throw new Exception();
		}
		catch(Exception e)
		{
			System.out.println("Exception--->"+e);
		}
		finally//whether there is exception or not,finally block executes its job anyways
		{
			System.out.println("Hello");
		}
	}

}
