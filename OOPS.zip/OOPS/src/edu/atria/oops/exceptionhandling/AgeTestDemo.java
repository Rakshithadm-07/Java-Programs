package edu.atria.oops.exceptionhandling;
import java.util.Scanner;

public class AgeTestDemo {
	
	static void validate(int age) throws InvalidAgeException
	{
		if(age<18)
		{
			throw new InvalidAgeException("invalid age you are not eligible to vote");
			
		}
		else 
		{
			System.out.println("you are eligible to vote");
		}
	}
	
	public static void main(String[] args) {
		int age;
		Scanner sc =  new Scanner(System.in);
		System.out.println("Enter your age");
		age=sc.nextInt();
		try
		{
			validate(age);
		}
		catch(InvalidAgeException i) {
			System.out.println("Exception caught----" + i.getMessage());
			
		}
		sc.close();
		
		

	}

}
