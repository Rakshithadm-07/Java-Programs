package edu.atria.oops.exceptionhandling;

//Program To Demonstrate custom exception

public class InvalidAgeException extends Exception {
	public InvalidAgeException() {
		super("Invalid");
	}
	public InvalidAgeException(String message) {
		super(message);
	}
	

}
