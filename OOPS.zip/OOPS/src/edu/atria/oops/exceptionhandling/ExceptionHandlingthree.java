package edu.atria.oops.exceptionhandling;

public class ExceptionHandlingthree {
	public void Demo()
	{
		int a=5/0;
		System.out.println(a);
		
	}
	public void Slave()
	{
		try
		{
			Demo();
		}
		catch(Exception e)
		{
			System.out.println("Exception----->"+e);
		}
	}
	public static void main(String[] args)
	{
		ExceptionHandlingthree obj = new ExceptionHandlingthree();
		obj.Slave();
	}

}
