package edu.atria.oops.exceptionhandling;

public class ExceptionHandling {
	
	public static void main(String[] args) {
		
	try
	{
		int a=5/1;
		System.out.println(a);//if 1st condition is true then it displays o/p & moves forward
	    //else it displays the 1st case exception and skips if there is any 2nd exception
	    
	    try
	    {
	    	int arr[] = {2};
	    	arr[10]=25;
	    }
	    
	    catch(ArrayIndexOutOfBoundsException e)
	    {
	    	System.out.println("oh---->"+e);
	    }
	    
	}
	catch (Exception e)
	{
		System.out.println("Exception-------->"+e);
	}

}
}
