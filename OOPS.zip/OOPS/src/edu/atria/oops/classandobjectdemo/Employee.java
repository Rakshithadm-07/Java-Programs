package edu.atria.oops.classandobjectdemo;

public class Employee {
	
	private int id;//we cann't access outside of class;
	private String name;
	private float salary;
	private String department;
	
	public Employee() {//constructor;
		System.out.println("Default constructor is called.....");
	}
	//parameter constructor;
	public Employee(int id,String name,float salary,String department){
		//This keyword used to separate;
		this.id=id;
		this.name=name;
		this.salary=salary;
		this.department=department;
		System.out.println("Parameterized constructor is called....");
		
	}
	//Concept of encapsulation,data hiding;
	//go to source click on generate getter and setter;
	//taking getter(read only) and setter(write only);

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public float getSalary() {
		return salary;
	}

	public void setSalary(float salary) {
		this.salary = salary;
	}

	public String getDepartment() {
		return department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}
	//Go to source click on generate toString;
	@Override
	public String toString() {//object class;
		return "Employee [id=" + id + ", name=" + name + ", salary=" + salary + ", department=" + department + "]";
	}
	
	
	
	
	
	
	
	
	

}
