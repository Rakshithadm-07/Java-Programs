package edu.atria.oops.linkedistdemo;

public class VectorDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
