package edu.atria.oops.inheritancedemo;

public class Father extends Grandfather{

	private String fatherName;
    private String nationality;
    
    public Father(String grandfatherName, String address, String fatherName, String nationality) {
		super(grandfatherName, address);
        this.fatherName = fatherName;
	    this.nationality=nationality;
	
	
}

	public String getFatherName() {
		return fatherName;
	}

	public void setFatherName(String fatherName) {
		this.fatherName = fatherName;
	}

	public String getNationality() {
		return nationality;
	}

	public void setNationality(String nationality) {
		this.nationality = nationality;
	}

	@Override
	public String toString() {
		return "Father [fatherName=" + fatherName + ", nationality=" + nationality + ", getGrandfatherName()="
				+ getGrandfatherName() + ", getAddress()=" + getAddress() + ", toString()=" + super.toString()
				+ ", getClass()=" + getClass() + ", hashCode()=" + hashCode() + "]";
	}

	

}
