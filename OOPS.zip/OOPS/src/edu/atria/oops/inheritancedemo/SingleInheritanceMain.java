package edu.atria.oops.inheritancedemo;

public class SingleInheritanceMain {

	public static void main(String[] args) {
		Student sOne = new Student(123456780,"Indian","Bangalore","07/10/2002",'F',111,"Rakshitha","ISE");
		System.out.println(sOne);
		
	}

}
		
		
		
		
		


		
		
		
		