package edu.atria.oops.inheritancedemo;

public class Citizen {
	private long aadharNumber;
	private String nationality;
	private String address;
	private String dob;
	private char gender;
	
	public Citizen(long aadharNumber, String nationality, String address, String dob, char gender) {
		super();
		this.aadharNumber = aadharNumber;
		this.nationality = nationality;
		this.address = address;
		this.dob = dob;
		this.gender = gender;
	}

	public long getAadharNumber() {
		return aadharNumber;
	}

	public void setAadharNumber(long aadharNumber) {
		this.aadharNumber = aadharNumber;
	}

	public String getNationality() {
		return nationality;
	}

	public void setNationality(String nationality) {
		this.nationality = nationality;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getDob() {
		return dob;
	}

	public void setDob(String dob) {
		this.dob = dob;
	}

	public char getGender() {
		return gender;
	}

	public void setGender(char gender) {
		this.gender = gender;
	}

	@Override
	public String toString() {
		return "Citizen [aadharNumber=" + aadharNumber + ", nationality=" + nationality + ", address=" + address
				+ ", dob=" + dob + ", gender=" + gender + ", getClass()=" + getClass() + ", hashCode()=" + hashCode()
				+ ", toString()=" + super.toString() + "]";
	}

	
	
	
	
	

}
