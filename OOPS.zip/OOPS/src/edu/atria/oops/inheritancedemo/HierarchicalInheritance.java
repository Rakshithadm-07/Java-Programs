package edu.atria.oops.inheritancedemo;

public class HierarchicalInheritance {

	public static void main(String[] args) {
		Mp mpOne = new Mp(123456780,"Indian","Bangalore","07/10/2002",'M',111,"Rakshith","Hebbala","BJP");
		System.out.println(mpOne);

	}

}