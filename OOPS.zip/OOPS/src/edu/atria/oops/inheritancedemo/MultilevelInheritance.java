package edu.atria.oops.inheritancedemo;

public class MultilevelInheritance {

	public static void main(String[] args) {
	    Son sonOne = new Son("Manju","Hebbala","Bharath","Indian","Rakesh","ISE");
		System.out.println(sonOne);
	    
	}

	

}
