package edu.atria.oops.inheritancedemo;

public class Son extends Father{
	private String sonName;
	private String department;

	public Son(String grandfatherName, String address, String fatherName, String nationality, String sonName, String department) {
		super(grandfatherName, address, fatherName, nationality);
		this.sonName=sonName;
		this.department=department;
		
	}


}
