package edu.atria.oops.inheritancedemo;

public class Grandfather{
	private String grandfatherName;
	private String address;
	
	
	
	public Grandfather(String grandfatherName,String address){
		super();
		this.grandfatherName=grandfatherName;
		this.address=address;
		
		
	}



	public String getGrandfatherName() {
		return grandfatherName;
	}



	public void setGrandfatherName(String grandfatherName) {
		this.grandfatherName = grandfatherName;
	}



	public String getAddress() {
		return address;
	}



	public void setAddress(String address) {
		this.address = address;
	}



	@Override
	public String toString() {
		return "Grandfather [grandfatherName=" + grandfatherName + ", address=" + address + ", getClass()=" + getClass()
				+ ", hashCode()=" + hashCode() + ", toString()=" + super.toString() + "]";
	}

	
}
