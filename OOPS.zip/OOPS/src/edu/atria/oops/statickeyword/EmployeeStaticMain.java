package edu.atria.oops.statickeyword;

public class EmployeeStaticMain {
	
	public static void main(String[] args) {
		
		
		System.out.println(EmployeeStatic.getCompanyName());
		EmployeeStatic eOne = new EmployeeStatic("Rakshitha",101);
		System.out.println(eOne);
		
		EmployeeStatic eTwo = new EmployeeStatic("Bharath",102);
		System.out.println(eTwo);
	}

}
