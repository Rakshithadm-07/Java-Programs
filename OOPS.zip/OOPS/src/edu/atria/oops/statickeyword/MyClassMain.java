package edu.atria.oops.statickeyword;

public class MyClassMain {

	public static void main(String[] args) {
		
		MyClass objOne = new MyClass();
		System.out.println(objOne);
		
		MyClass.display();
		
		MyClass objTwo = new MyClass();
		MyClass.display();

	}

}
