package edu.atria.oops.statickeyword;

public class MyClass {
	private int section;//non static or instance variable;
	private static int srNo;
	//static block
	
	static {
		System.out.println("------------within static block-------------");
		srNo=1000;
		
	}
	
	//default constructor
	MyClass(){
		System.out.println("within default constructor");
		srNo++;//Post increament 
	}

	@Override
	public String toString() {
		return "MyClass [section=" + section + ", srNo=" + srNo + "]";
	}
	
	static void display() {
		//Cannot access not static member from a static member
		//System.out.println(section);
		System.out.println(srNo);
	}

}
