package edu.atria.oops.finalkeyword;

final class FinalClass {
	
	void show() {
		System.out.println("Final class cannot be inherited");
	}
}

//can't create child classes from Final class,Ex.String Wrapper Classes, System,
//class FinalChildClass extends FinalClass{
	
//}



public class FinalClassDemo {
	public static void main(String[] args) {
		//create the object of final class
		FinalClass f1 = new FinalClass();//call show() method using object referer
		f1.show();
	}

}
