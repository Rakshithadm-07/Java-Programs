package edu.atria.oops.finalkeyword;

public class FinalVariable {
	
	//final int x;//final instance variable must be installed
	static int x = 100;
	
	//Declare a static blank final variable
	static int y = 20;
	
	//Declare and Initialize static final variable 
	//final static int z = 10; skip 
	
	//instance method
	void change() {
		x=30;//final variables can't be reassigned
		y=200;//final static variables can;t be reassigned
	}

	@Override
	public String toString() {
		return "FinalVariable [x=" + x + ",y=" + y+"]";
	}
	
	//Declare a static block to initialize the final,final static variable
	static {
		x = 25;
		y =100;//Once initialize can't be reassigned
		System.out.println("Value of y:" +y);
	}
	
}
	

/*1Final class
 * cannot be inherited
 * 2.Final methods
 * cannot be overrider
 * 3.Final variables and final static variables
 * must be initialised
 * cannot be reassigned
 * */
