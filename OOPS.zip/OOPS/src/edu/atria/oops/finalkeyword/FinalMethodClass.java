package edu.atria.oops.finalkeyword;

//Class with a final method
public class FinalMethodClass {
	//Default constructor
	FinalMethodClass(){
		System.out.println("This is a default constructoe");
		
	}
	
	//final int a;
	final int a = 50;
	
	//Final Method
	final void show() {
		System.out.println("Value of a:");
	}

}
